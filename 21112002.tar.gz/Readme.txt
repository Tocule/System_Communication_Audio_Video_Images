1 Run gcc ur.c -o ur
2 Run gcc us.c -o us
3 Run gcc up.c -o up
4 ur should be run as ./ur [PORTNO]
5 us should be run as ./us [PORTNO] [Filename.format]
5 up has 3 arguments ./up [OPTION] [Max_file_size](in Bytes)
6 You can just type ./up to see menu command
7 If sent filename is image.jpg then received filename will be imag2.jpg or if Pixels.mp4 is sent then received file will be Pixel2.jpg
7 After Seeing menu you can do desired operations
8 ./up 1 requires PORTNO
9 ./up 2 will ask you for PORTNO,the Filename.format[no spaces in filename](video,audio,image)
10 ./up 3 will Exit the program
11 Program can also send larger files
